package com.example.onlineshopping.entity.customer;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "customers")
public class customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;

    @OneToMany(mappedBy = "customer")
    private List<com.example.onlineshopping.entity.customerorder.customerOrder> orders;

    // Getters and Setters omitted for brevity
}

package com.example.onlineshopping.entity.customerorder;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import com.example.onlineshopping.entity.customer.Customer;
import com.example.onlineshopping.entity.orderitem.OrderItem;
@Entity
@Table(name = "customer_orders")
public class CustomerOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime orderDate;
    private String status; // example: placed, canceled, completed
    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> orderItems;
    private double totalPrice;
    // Getters and Setters omitted for brevity
}

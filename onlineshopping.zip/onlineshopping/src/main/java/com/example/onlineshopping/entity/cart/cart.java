package com.example.onlineshopping.entity.cart;
import jakarta.persistence.*;
import java.util.List;
import com.example.onlineshopping.entity.customer.Customer;
import com.example.onlineshopping.entity.cartitem.CartItem;
@Entity
@Table(name = "carts")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CartItem> items;
    // Getters and Setters omitted for brevity
}

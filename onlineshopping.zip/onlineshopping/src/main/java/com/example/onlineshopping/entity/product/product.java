package com.example.onlineshopping.entity.product;
import jakarta.persistence.*;
@Entity
@Table(name = "products")
public class product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private double price;
    private int stockQuantity;
    // Getters and Setters omitted for brevity
}

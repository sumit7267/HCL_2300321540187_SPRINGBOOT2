package com.example.onlineshopping.entity.cartitem;
import jakarta.persistence.*;
import com.example.onlineshopping.entity.cart.Cart;
import com.example.onlineshopping.entity.product.Product;
@Entity
@Table(name = "cart_items")
public class CartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "cart_id")
    private Cart cart;
    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;
    private int quantity;
    // Getters and Setters omitted for brevity
}

package com.example.onlineshopping.entity.orderitem;
import jakarta.persistence.*;
import com.example.onlineshopping.entity.customerorder.CustomerOrder;
import com.example.onlineshopping.entity.product.Product;
@Entity
@Table(name = "order_items")
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "order_id")
    private CustomerOrder order;
    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;
    private int quantity;
    private double priceAtPurchase;
    // Getters and Setters omitted for brevity
}
